// Checks clue files (images / audio / video) against the dev server.
// Run the dev server (npm run dev), then: node tests/media-flow.mjs
import { readFileSync } from "node:fs";
const PORT = process.env.PORT ?? "5173";
const B = `http://localhost:${PORT}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let fails = 0;
const check = (label, cond, extra = "") => { if (!cond) fails++; console.log((cond ? "PASS " : "FAIL ") + label + (cond ? "" : "  " + extra)); };
const { code, hostKey } = await (await fetch(B + "/api/rooms", { method: "POST" })).json();
const open = () => new Promise((res) => { const w = new WebSocket(`ws://localhost:${PORT}/parties/room/${code}`); w.msgs = []; w.onmessage = (e) => w.msgs.push(JSON.parse(String(e.data))); w.onopen = () => res(w); });
const send = async (w, o, ms = 250) => { const n = w.msgs.length; w.send(JSON.stringify(o)); await sleep(ms); return w.msgs.slice(n); };
const G = (w) => [...w.msgs].reverse().find((m) => m.type === "lobby").lobby.game;
const err = (arr) => arr.find((m) => m.type === "error" || m.type === "clueFileErrors");

const host = await open(); await send(host, { type: "rejoin", key: hostKey });
const a = await open(), tv = await open();
await send(a, { type: "join", name: "Sam" }); await send(a, { type: "chooseRole", role: "player" }); await send(a, { type: "createTeam", name: "Owls" });
await send(tv, { type: "join", name: "TV" }); await send(tv, { type: "chooseRole", role: "display" });

const bad = JSON.parse(readFileSync("samples/sample-media-clues.json", "utf8"));
bad.boards[0].columns[0].questions[0].questionMedia = { type: "gif", src: "x" };
check("bad media rejected with a clear error", err(await send(host, { type: "loadClues", text: JSON.stringify(bad) }))?.errors?.some((e) => e.includes("questionMedia")));
bad.boards[0].columns[0].questions[0].questionMedia = { type: "image", src: "photo.jpg" };
check("src without / or http rejected", err(await send(host, { type: "loadClues", text: JSON.stringify(bad) }))?.errors?.some((e) => e.includes("src must start")));

await send(host, { type: "loadClues", text: readFileSync("samples/sample-media-clues.json", "utf8") });
check("host summary lists every file", G(host).clues.media.length === 6, JSON.stringify(G(host).clues.media));
await send(host, { type: "startGame" });

// Image clue: buzzers open straight away
await send(host, { type: "pickClue", column: 0, row: 0 });
check("image clue: buzzers open immediately", G(tv).current.waitingForMedia === false && G(tv).current.buzzDeadline !== null);
check("everyone sees the question image", G(a).current.questionMedia?.src === "/media/sample-image.svg");
await send(host, { type: "reveal" }); await send(host, { type: "continue" });

// Answer media: only the host before the reveal
await send(host, { type: "pickClue", column: 0, row: 1 });
check("answer file hidden from players before reveal", G(a).current.answerMedia === null && G(host).current.answerMedia !== null);
await send(host, { type: "reveal" });
check("answer file shown to everyone on reveal", G(a).current.answerMedia?.src === "/media/sample-image.svg");
await send(host, { type: "continue" });

// Audio clue: wait for it to finish
await send(host, { type: "pickClue", column: 1, row: 0 });
check("audio clue: waiting, no buzz timer yet", G(tv).current.waitingForMedia === true && G(tv).current.buzzDeadline === null);
check("buzz refused while audio plays", err(await send(a, { type: "buzz" }))?.message === "Wait for the clue to finish");
check("players can't end the clip", err(await send(a, { type: "mediaFinished" }))?.code === "NOT_ALLOWED");
await send(tv, { type: "mediaFinished" });
check("display says it ended -> buzz timer starts", G(tv).current.waitingForMedia === false && G(tv).current.buzzDeadline > Date.now());
await send(tv, { type: "mediaFinished" });
check("a second report changes nothing", G(tv).phase === "clue");
await send(a, { type: "buzz" });
check("buzz works after the clip", G(tv).phase === "answering");
await send(host, { type: "judge", correct: true }); await send(host, { type: "continue" });

// Video clue: host opens buzzers manually
await send(host, { type: "pickClue", column: 2, row: 0 });
check("video clue: waiting", G(tv).current.waitingForMedia === true);
await send(host, { type: "mediaFinished" });
check("host 'open buzzers now' works", G(tv).current.waitingForMedia === false && G(tv).current.buzzDeadline !== null);
await send(host, { type: "reveal" }); await send(host, { type: "continue" });

// Final with an audio clue
await send(host, { type: "endRound" });
check("final wager", G(tv).phase === "finalWager");
check("final clue file hidden during wagers", G(tv).final.questionMedia === null);
await send(a, { type: "finalWager", amount: 100 });
await send(host, { type: "showFinalClue" });
check("final audio: timer waits", G(tv).final.waitingForMedia === true && G(tv).final.deadline === null);
check("can type the answer while it plays", !err(await send(a, { type: "finalAnswer", text: "A" })));
await send(tv, { type: "mediaFinished" });
check("final timer starts after the clip", G(tv).final.deadline > Date.now() && G(tv).final.waitingForMedia === false);
check("final answer file hidden from display until game over", G(tv).final.answerMedia === null && G(host).final.answerMedia !== null);
console.log(fails ? `${fails} FAILED` : "ALL PASSED");
process.exit(0);
